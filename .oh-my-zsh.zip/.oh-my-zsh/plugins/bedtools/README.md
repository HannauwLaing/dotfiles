# Bedtools plugin

This plugin adds support for the [bedtools suite](http://bedtools.readthedocs.org/en/latest/):

* Adds autocomplete options for all bedtools sub commands.
